//adapted from https://codemirror.net/5/addon/hint/javascript-hint.js

  var ms3any=
(`
function(){}
map(function(){})
reduce(function(){})
`+
/* devtool F12

console.log(
[...document.querySelectorAll('td a:nth-child(1), td b:nth-child(1)')].map(x=>x.textContent).filter(x=>x.length>0&&!~x.indexOf('More...')&&!~x.indexOf('::')).join('\n')
)

*/
`
// classes   https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/namespace_ms_1_1_plugin_a_p_i.html

Channel
//Chord
//ChordRest
Cursor
//DurationElement
Element
//Enum
Excerpt
FileIO
//FractionWrapper
Instrument
Measure
MsProcess
MStyle
//Note
Page
Part
PlayEvent
//PluginAPI
QmlExcerptsListAccess
QmlListAccess
QmlPlayEventsListAccess
Score
//ScoreElement
ScoreView
// Segment
Selection
Staff
StringData
Tie
Tuplet
//Selection
MStyle

//?
//tieWrap
//selectionWrap
//wrap







// PluginAPI   https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html

run
state.selectionChanged
state.excerptsChanged
state.instrumentsChanged
state.startLayoutTick
state.endLayoutTick

newScore
newElement
removeElement
Element
// cmd
writeScore
readScore
closeScore
// log
// logn
// log2
// openLog
// closeLog
fraction

menuPath
filePath
version
description
pluginType
dockArea
requiresScore
division
mscoreVersion
mscoreMajorVersion
mscoreMinorVersion
mscoreUpdateVersion
mscoreDPI
curScore
scores











// baseclass scoreelement  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_score_element.html

userName
is

type
name





// element  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_element.html
// handpicked

clone
subtypeName

parent
staff
offsetX
offsetY
color
visible
z
placement
velocity
autoplace
play
voice

stemDirection
noStem




// score  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_score.html

curScore.selection.elements
curScore.newCursor()
curScore.startCmd()
curScore.endCmd()


metaTag
setMetaTag
appendPart
appendPartByMusicXmlId
appendMeasures
addText
newCursor
firstSegment
extractLyrics
startCmd
endCmd
createPlayEvents

composer
duration
excerpts
firstMeasure
firstMeasureMM
harmonyCount
hasHarmonies
hasLyrics
keysig
lastMeasure
lastMeasureMM
lastSegment
lyricCount
scoreName
nmeasures
npages
nstaves
ntracks
nstaves
parts
lyricist
title
mscoreVersion
mscoreRevision
selection
style
pageNumberOffset
staves



// cursor https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_cursor.html

Cursor.SCORE_START
Cursor.SELECTION_START
Cursor.SELECTION_END

Cursor.INPUT_STATE_INDEPENDENT
Cursor.INPUT_STATE_SYNC_WITH_SCORE

rewind
rewind(Cursor.SCORE_START)
rewind(Cursor.SELECTION_START)
rewind(Cursor.SELECTION_END)
rewindToTick
next
nextMeasure
prev
add
addNote
addRest
addTuplet
setDuration

track
staffIdx
voice
filter
tick
time
tempo
keySignature
score
// element  unreliable
segment
measure
stringNumber
inputStateMode





// selection https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_selection.html

select
selectRange
deselect
clear

elements
isRange
startSegment
endSegment
startStaff




// segment   https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_segment.html

elementAt

annotations
nextInMeasure
next
prevInMeasure
prev
segmentType
//tick duplicate




// DurationElement  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_duration_element.html#a47ccec6b0522f715e80c4042ec588359

duration
globalDuration
actualDuration
tuplet




// chordrest https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_chord_rest.html

beam
//lyrics duplicate




// chord https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_chord.html

//add  duplicate
remove

graceNotes
notes
stem
stemSlash
hook
noteType
playEventType





// note https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_note.html
// handpicked

pitch
tuning
tpc
tpc1
tpc2
fret
string




//  fraction  eg timesig    https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_fraction_wrapper.html

numerator
denominator
ticks
str

`).replace(/\/\/.*/g,'')
.replace(/\n/g,' ')
.replace(/(\s){2,}/g,' ')
.split(' ')
.filter(x=>x.length>0)














/* enum
TOC https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/namespacemembers.html
parents  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/class_ms_1_1_plugin_a_p_i_1_1_plugin_a_p_i.html
listall Ms  https://musescore.github.io/MuseScore_PluginAPI_Docs/plugins/html/namespace_ms.html
*/

//no sort
.concat(
[
['Element',` 
  NOTE,
  CHORD,REST,
  SEGMENT,
  TEMPO_TEXT, STAFF_TEXT, SYSTEM_TEXT, DYNAMIC,
  STEM,
  CLEF, KEYSIG, TIMESIG
`]
].reduce((a,b)=>a.concat(b[1].replace(/[\s\n]/g,'').split(',').map(x=>b[0]+'.'+x)),[])
)
//sort
.concat(
[
['Element',`
            BRACKET_ITEM, PART, STAFF,
  SCORE, SYMBOL, TEXT, MEASURE_NUMBER,
  INSTRUMENT_NAME, SLUR_SEGMENT, TIE_SEGMENT, BAR_LINE,
  STAFF_LINES, SYSTEM_DIVIDER, STEM_SLASH, ARPEGGIO,
  ACCIDENTAL, LEDGER_LINE,
  AMBITUS, 
   BREATH, REPEAT_MEASURE, TIE,
  ARTICULATION, FERMATA, CHORDLINE,
  BEAM, HOOK, LYRICS, FIGURED_BASS,
  MARKER, JUMP, FINGERING, TUPLET,
   REHEARSAL_MARK,
  INSTRUMENT_CHANGE, STAFFTYPE_CHANGE, HARMONY, FRET_DIAGRAM,
  BEND, TREMOLOBAR, VOLTA, HAIRPIN_SEGMENT,
  OTTAVA_SEGMENT, TRILL_SEGMENT, LET_RING_SEGMENT, VIBRATO_SEGMENT,
  PALM_MUTE_SEGMENT, TEXTLINE_SEGMENT, VOLTA_SEGMENT, PEDAL_SEGMENT,
  LYRICSLINE_SEGMENT, GLISSANDO_SEGMENT, LAYOUT_BREAK, SPACER,
  STAFF_STATE, NOTEHEAD, NOTEDOT, TREMOLO,
  IMAGE, MEASURE, SELECTION, LASSO,
  SHADOW_NOTE, TAB_DURATION_SYMBOL, FSYMBOL, PAGE,
  HAIRPIN, OTTAVA, PEDAL, TRILL,
  LET_RING, VIBRATO, PALM_MUTE, TEXTLINE,
  TEXTLINE_BASE, NOTELINE, LYRICSLINE, GLISSANDO,
  BRACKET, SYSTEM, COMPOUND,
   SLUR, ELEMENT, ELEMENT_LIST,
  STAFF_LIST, MEASURE_LIST, HBOX, VBOX,
  TBOX, FBOX, ICON, OSSIA,
  BAGPIPE_EMBELLISHMENT, STICKING, MAXTYPE
`]
,['Accidental',`
  NONE, FLAT, NATURAL, SHARP,
  SHARP2, FLAT2, SHARP3, FLAT3
`]
,['Direction',`AUTO, UP, DOWN `]
,['Placement',` ABOVE, BELOW `]
,['Tid',`
  DEFAULT, TITLE, SUBTITLE, COMPOSER,
  POET, LYRICS_ODD, LYRICS_EVEN, FINGERING,
  LH_GUITAR_FINGERING, RH_GUITAR_FINGERING, STRING_NUMBER, INSTRUMENT_LONG,
  INSTRUMENT_SHORT, INSTRUMENT_EXCERPT, DYNAMICS, EXPRESSION,
  TEMPO, METRONOME, MEASURE_NUMBER, TRANSLATOR,
  TUPLET, SYSTEM, STAFF, HARMONY_A,
  HARMONY_B, HARMONY_ROMAN, HARMONY_NASHVILLE, REHEARSAL_MARK,
  REPEAT_LEFT, REPEAT_RIGHT, FRAME, TEXTLINE,
  GLISSANDO, OTTAVA, VOLTA, PEDAL,
  LET_RING, PALM_MUTE, HAIRPIN, BEND,
  HEADER, FOOTER, INSTRUMENT_CHANGE, STICKING,
  USER1, USER2, USER3, USER4,
  USER5, USER6, USER7, USER8,
  USER9, USER10, USER11, USER12,
  TEXT_STYLES, IGNORED_STYLES
`]
].reduce((a,b)=>a.concat(b[1].replace(/[\s\n]/g,'').split(',').sort().map(x=>b[0]+'.'+x)),[])
)













//https://github.com/calculuswhiz/musescore-utils/blob/master/ValidCommands.txt
.concat(`
note-c note-d note-e note-f note-g note-a note-b 
chord-c chord-d chord-e chord-f chord-g chord-a chord-b
insert-c insert-d insert-e insert-f insert-g insert-a insert-b
fret-0 fret-1 fret-2 fret-3 fret-4 fret-5 fret-6 fret-7 fret-8 fret-9 fret-10 fret-11 fret-12 fret-13 fret-14
toggle-visible
reset-stretch
mirror-note
double-duration half-duration
inc-duration-dotted
dec-duration-dotted
add-staccato add-tenuto add-marcato add-sforzato add-trill
add-up-bow add-down-bow
add-8va add-8vb
note-longa note-longa-TAB
note-breve note-breve-TAB
pad-note-1 pad-note-1-TAB
pad-note-2 pad-note-2-TAB
pad-note-4 pad-note-4-TAB
pad-note-8 pad-note-8-TAB
pad-note-16 pad-note-16-TAB
pad-note-32 pad-note-32-TAB
pad-note-64 pad-note-64-TAB
pad-note-128 pad-note-128-TAB
reset-style reset-beammode reset-groupings
clef-violin clef-bass
voice-x12 voice-x13 voice-x14 voice-x23 voice-x24 voice-x34
pad-rest
pad-dot pad-dotdot pad-dot3 pad-dot4
beam-start beam-mid no-beam beam-32
sharp2 sharp nat flat flat2
flip
stretch+ stretch-
pitch-spell
select-all select-section
add-brackets
acciaccatura appoggiatura
grace4 grace16 grace32 grace8after grace16after grace32after
explode implode
slash-fill slash-rhythm
resequence-rehearsal-marks
del-empty-measures
add-audio
transpose-up transpose-down
delete
full-measure-rest
toggle-insert-mode
pitch-up pitch-down
time-delete pitch-up-octave pitch-down-octave
pad-note-increase pad-note-decrease pad-note-increase-TAB pad-note-decrease-TAB
toggle-mmrest toggle-hide-empty
set-visible unset-visible
system-break page-break section-break
relayout

escape
note-input
copy cut paste paste-half paste-double paste-special
swap
lyrics
figured-bass
mag
play
fotomode
add-slur add-hairpin add-hairpin-reverse add-noteline
chord-text title-text subtitle-text composer-text poet-text part-text system-text staff-text expression-text rehearsalmark-text instrument-change-text fingering-text
edit-element
select-similar select-similar-staff select-dialog
page-prev page-next page-top page-end
select-next-chord select-prev-chord select-next-measure select-prev-measure select-begin-line select-end-line select-begin-score select-end-score select-staff-above select-staff-below
next-chord prev-chord next-track prev-track next-measure prev-measure
pitch-up-diatonic pitch-down-diatonic
move-up move-down
up-chord down-chord top-chord bottom-chord
next-segment-element prev-segment-element
next-element prev-element
first-element last-element
rest rest-TAB
rest-1 rest-2 rest-4 rest-8
intervalX
tie chord-tie
duplet triplet quadruplet quintuplet sextuplet septuplet octuplet nonuplet tuplet-dialog
repeat-sel
voice-1 voice-2 voice-3 voice-4
enh-both enh-current
revision
append-measure insert-measure
insert-hbox insert-vbox append-hbox append-vbox
insert-textframe append-textframe insert-fretframe
move-left move-right
reset
show-omr
split-measure join-measures
next-lyric prev-lyric
add-remove-breaks
copy-lyrics-to-clipboard
realtime-advance
advance-longa
advance-breve
advance-1 advance-2 advance-4 advance-8 advance-16 advance-32 advance-64
prev-measure-TEXT next-measure-TEXT
prev-beat-TEXT next-beat-TEXT
string-above string-below
text-word-left text-word-right
concert-pitch
`.replace(/\/\/.*/g,'')
.replace(/\n/g,' ')
.replace(/(\s){2,}/g,' ')
.split(' ')
.filter(x=>x.length>0)
.map(x=>`cmd("${x}")`)
)















// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: https://codemirror.net/5/LICENSE

;(function(mod) {
  if (typeof exports == "object" && typeof module == "object") // CommonJS
    mod(require("../../lib/codemirror"));
  else if (typeof define == "function" && define.amd) // AMD
    define(["../../lib/codemirror"], mod);
  else // Plain browser env
    mod(CodeMirror);
})(function(CodeMirror) {

  var Pos = CodeMirror.Pos;

  function forEach(arr, f) {
    for (var i = 0, e = arr.length; i < e; ++i) f(arr[i]);
  }

  function arrayContains(arr, item) {
    if (!Array.prototype.indexOf) {
      var i = arr.length;
      while (i--) {
        if (arr[i] === item) {
          return true;
        }
      }
      return false;
    }
    return arr.indexOf(item) != -1;
  }

  function scriptHint(editor, keywords, getToken, options) {
    // Find the token at the cursor
    var cur = editor.getCursor(), token = getToken(editor, cur);
    if (/\b(?:string|comment)\b/.test(token.type)) return;
    var innerMode = CodeMirror.innerMode(editor.getMode(), token.state);
    if (innerMode.mode.helperType === "json") return;
    token.state = innerMode.state;

    // If it's not a 'word-style' token, ignore the token.
    if (!/^[\w$_]*$/.test(token.string)) {
      token = {start: cur.ch, end: cur.ch, string: "", state: token.state,
               type: token.string == "." ? "property" : null};
    } else if (token.end > cur.ch) {
      token.end = cur.ch;
      token.string = token.string.slice(0, cur.ch - token.start);
    }

    var tprop = token;
    // If it is a property, find out what it is a property of.
    while (tprop.type == "property") {
      tprop = getToken(editor, Pos(cur.line, tprop.start));
      if (tprop.string != ".") return;
      tprop = getToken(editor, Pos(cur.line, tprop.start));
      if (!context) var context = [];
      context.push(tprop);
    }
    return {list: getCompletions(token, context, keywords, options),
            from: Pos(cur.line, token.start),
            to: Pos(cur.line, token.end)};
  }

  function ms3pHint(editor, options) {
    return scriptHint(editor, keywords,
                      function (e, cur) {return e.getTokenAt(cur);},
                      options);
  };
  CodeMirror.registerHelper("hint", "javascript", ms3pHint);

  var stringProps = ("charAt charCodeAt indexOf lastIndexOf substring substr slice trim trimLeft trimRight " +
                     "toUpperCase toLowerCase split concat match replace search").split(" ");
  var arrayProps = ("length concat join splice push pop shift unshift slice reverse sort indexOf " +
                    "lastIndexOf every some filter forEach map reduce reduceRight ").split(" ");
  var funcProps = "prototype apply call bind".split(" ");
  var keywords = ("break case catch class const continue debugger default delete do else export extends false finally for function " +
                  "if in import instanceof new null return super switch this throw true try typeof var void while with yield").split(" ").concat(ms3any)

  function forAllProps(obj, callback) {
    if (!Object.getOwnPropertyNames || !Object.getPrototypeOf) {
      for (var name in obj) callback(name)
    } else {
      for (var o = obj; o; o = Object.getPrototypeOf(o))
        Object.getOwnPropertyNames(o).forEach(callback)
    }
  }

  function getCompletions(token, context, keywords, options) {
    var found = [], start = token.string, global = options && options.globalScope || window;
    function maybeAdd(str) {
      var strlc=str.charAt(0)+str.slice(1).toLowerCase()
      if (
        !arrayContains(found, str) &&
        ( strlc.lastIndexOf(start, 0) == 0 
          || ( start.length>2 && ~strlc.indexOf(start) )
        )
      ) found.push(str)
    }
    function gatherCompletions(obj) {
      if (typeof obj == "string") forEach(stringProps, maybeAdd);
      else if (obj instanceof Array) forEach(arrayProps, maybeAdd);
      else if (obj instanceof Function) forEach(funcProps, maybeAdd);
      else { forEach(ms3any, maybeAdd) }
      forAllProps(obj, maybeAdd)
    }

    if (context && context.length) {
      // If this is a property, see if it belongs to some object we can
      // find in the current environment.
      var obj = context.pop(), base;
      if (obj.type && obj.type.indexOf("variable") === 0) {
        if (options && options.additionalContext)
          base = options.additionalContext[obj.string];
        if (!options || options.useGlobalScope !== false)
          base = base || global[obj.string];
      } else if (obj.type == "string") {
        base = "";
      } else if (obj.type == "atom") {
        base = 1;
      } else if (obj.type == "function") {
        if (global.jQuery != null && (obj.string == '$' || obj.string == 'jQuery') &&
            (typeof global.jQuery == 'function'))
          base = global.jQuery();
        else if (global._ != null && (obj.string == '_') && (typeof global._ == 'function'))
          base = global._();
      }
      while (base != null && context.length)
        base = base[context.pop().string];
      /*if (base != null)*/ gatherCompletions(base)
    } else {
      // If not, just look in the global object, any local scope, and optional additional-context
      // (reading into JS mode internals to get at the local and global variables)
      for (var v = token.state.localVars; v; v = v.next) maybeAdd(v.name);
      for (var c = token.state.context; c; c = c.prev)
        for (var v = c.vars; v; v = v.next) maybeAdd(v.name)
      for (var v = token.state.globalVars; v; v = v.next) maybeAdd(v.name);
      if (options && options.additionalContext != null)
        for (var key in options.additionalContext)
          maybeAdd(key);
      if (!options || options.useGlobalScope !== false)
        gatherCompletions(global);
      forEach(keywords, maybeAdd);
    }
    return found;
  }
});
