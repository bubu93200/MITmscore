---
layout: page
title: "About Jack"
---

JACK (JACK Audio Connection Kit) refers to an [API](/api) and two
implementations of this API, jack1 and jack2. It provides a basic
infrastructure for audio applications to communicate with each other and
with audio hardware.  Through JACK, users are enabled to build powerful
systems for signal processing and music production.
